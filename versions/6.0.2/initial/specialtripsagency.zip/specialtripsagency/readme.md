Repository Init Content
=======================

This is still work in progress. Please get in touch with npatel@redhat.com if you need more info on this.

changes by shepherd
